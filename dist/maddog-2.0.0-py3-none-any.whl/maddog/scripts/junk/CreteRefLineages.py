from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import pandas as pd
from Bio import Phylo, SeqIO
from argparse import ArgumentParser
from Bio.Phylo.BaseTree import Clade, Tree

class CreateRefLineages:
    def __init__(self, tree, ancestral_fasta, base_dir, ancestral_prefix, ancestral_digits, ancestral_index_base, support_mode, internal_order, no_tip_labels, min_bootstrap, min_tips):
        self.tree = tree
        self.ancestral_fasta = ancestral_fasta
        self.base_dir = base_dir
        self.ancestral_prefix = ancestral_prefix
        self.ancestral_digits = ancestral_digits
        self.ancestral_index_base = ancestral_index_base
        self.support_mode = support_mode
        self.internal_order = internal_order
        self.no_tip_labels = no_tip_labels
        self.min_bootstrap = min_bootstrap
        self.min_tips = min_tips
        self.qualifying_nodes = qualifying_nodes


if __name__ == "__main__":
    parser = ArgumentParser(description="Assigns the lineages to the reference tree nodes based on the provided IQ-TREE Newick tree and optional ancestral sequences FASTA.")

    parser.add_argument( "--tree", "--contree", dest="tree", required=True, help="IQ-TREE Newick tree file, for example .treefile or .contree.",)
    parser.add_argument( "--ancestral_fasta", default=None, help="Optional ancestral sequences FASTA. IDs usually look like NODE_0000000.",)
    parser.add_argument("--base_dir", default="tmp", help="Base directory where the output directory or files are created")
    parser.add_argument("--output",default="NodeAssignment",help="Output table path. Use .csv for CSV; otherwise TSV is written.",)
    parser.add_argument("--ancestral_prefix",default="NODE_",help="Prefix used by ancestral node FASTA IDs. Default: NODE_",)
    parser.add_argument("--ancestral_digits",type=int,default=7,help="Number of zero-padding digits in ancestral node IDs. Default: 7",)
    parser.add_argument("--ancestral_index_base",type=int,default=0,help="Base index for ancestral node IDs. Default 0 maps first internal node to NODE_0000000.",)
    parser.add_argument("--support_mode",choices=["ufboot", "second", "shalrt", "alrt", "first"],default="ufboot",help="How to parse labels like SH-aLRT/UFBoot. Default: ufboot/second value.",)
    parser.add_argument("--internal_order",choices=["preorder", "postorder", "level"],default="preorder",help="Internal node traversal order. Keep preorder to match the referenced MADDOG node_info.py logic.",)
    parser.add_argument( "--no_tip_labels",action="store_true",help="Do not write the descendant_tip_labels column. Useful for very large trees.",)
    parser.add_argument("--min_bootstrap",type=int,default=95.0,help="Minimum bootstrap/UFBoot value required to keep an internal node. Default: 95.",)
    parser.add_argument("--min_tips",type=int,default=10,help="Minimum number of descendant tips required to keep an internal node. Default: 10, matching the MADDOG concept.",)
    parser.add_argument("--observed_fasta",default=None,help="Observed aligned FASTA used for descendant difference checking.")
    parser.add_argument("--no_descendant_difference_filter",action="store_true",help="Do not filter by descendant ancestral sequence difference.")
    parser.add_argument("--qualifying_nodes",action="store_true",help="Qualifying output nodes, an output from the AssignNodeDetails script")


    args = parser.parse_args()

    checker = CreateRefLineages(
        args.tree,
        args.ancestral_fasta,
        args.base_dir,
        args.ancestral_prefix,
        args.ancestral_digits,
        args.ancestral_index_base,
        args.support_mode,
        args.internal_order,
        args.no_tip_labels,
        args.min_bootstrap,
        args.min_tips,
        args.qualifying_nodes
    )

    df = checker.node_table()