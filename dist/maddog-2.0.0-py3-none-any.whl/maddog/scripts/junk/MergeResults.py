#!/usr/bin/env python3
"""
Compatibility runner for MADDOG merge_results.py.

This script normalizes the outputs from SeqDesignation.py, loads the current
upstream merge_results.py as a core module, runs run_postprocess(), and writes
all returned result tables.

Keep the upstream MADDOG merge script unchanged as merge_results_core.py in the
same directory, or provide its path with --core_script.
"""

from argparse import ArgumentParser
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import sys

import pandas as pd


class MergeResults:
    def __init__(
        self,
        core_script,
        node_data,
        seq_data,
        metadata,
        assignments,
        alignment,
        tree,
        ancestral,
        datasets_dir,
        ref_lineage,
        outdir,
        min_update_count,
        max_update_iter,
    ):
        self.core_script = Path(core_script)
        self.node_data = Path(node_data)
        self.seq_data = Path(seq_data)
        self.metadata = Path(metadata)
        self.assignments = Path(assignments)
        self.alignment = Path(alignment)
        self.tree = Path(tree)
        self.ancestral = Path(ancestral) if ancestral else None
        self.datasets_dir = Path(datasets_dir)
        self.ref_lineage = Path(ref_lineage)
        self.outdir = Path(outdir)
        self.min_update_count = min_update_count
        self.max_update_iter = max_update_iter

    def read_table(self, path):
        path = Path(path)
        attempts = [
            {"sep": "\t"},
            {"sep": ","},
            {"sep": None, "engine": "python"},
            {"sep": r"\s+", "engine": "python"},
        ]

        errors = []
        for options in attempts:
            try:
                dataframe = pd.read_csv(
                    path,
                    dtype=str,
                    keep_default_na=False,
                    **options,
                )
                dataframe.columns = [str(x).strip() for x in dataframe.columns]
                if len(dataframe.columns) > 1:
                    return dataframe
            except (pd.errors.ParserError, UnicodeDecodeError, ValueError) as error:
                errors.append(str(error))

        raise ValueError(
            f"Could not parse table: {path}. "
            f"Last errors: {' | '.join(errors[-3:])}"
        )

    def write_table(self, dataframe, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        dataframe.to_csv(path, sep="\t", index=False, na_rep="NA")

    def clean_ids(self, dataframe, column):
        result = dataframe.copy()
        result[column] = result[column].astype(str).str.strip()
        invalid = {"", "none", "nan", "na", "null"}
        return result.loc[~result[column].str.lower().isin(invalid)].copy()

    def normalize_node_data(self, dataframe):
        result = dataframe.copy()

        if "node" not in result.columns:
            if "Node" in result.columns:
                result["node"] = result["Node"]
            else:
                raise ValueError(
                    "Node data must contain 'node' or 'Node'. "
                    f"Available columns: {list(result.columns)}"
                )

        if "lineage" not in result.columns:
            if "new_lineage" in result.columns:
                result["lineage"] = result["new_lineage"]
            else:
                raise ValueError(
                    "Node data must contain 'lineage'. "
                    f"Available columns: {list(result.columns)}"
                )

        if "number" not in result.columns:
            ordered = result.copy()
            ordered["node_numeric"] = pd.to_numeric(
                ordered["node"], errors="coerce"
            )
            ordered = ordered.sort_values(
                ["node_numeric", "lineage"],
                kind="mergesort",
                na_position="last",
            )
            mapping = {
                index: str(number)
                for number, index in enumerate(ordered.index, start=1)
            }
            result["number"] = result.index.map(mapping)

        result["node"] = pd.to_numeric(result["node"], errors="coerce")
        result = result.loc[result["node"].notna()].copy()
        result["node"] = result["node"].astype(int)
        result["lineage"] = result["lineage"].astype(str).str.strip()
        result["number"] = result["number"].astype(str).str.strip()

        first = ["node", "lineage", "number"]
        remaining = [column for column in result.columns if column not in first]
        return result[first + remaining]

    def normalize_seq_data(self, dataframe):
        result = dataframe.copy()

        if "ID" not in result.columns:
            for candidate in ["primary_accession", "id", "accession"]:
                if candidate in result.columns:
                    result["ID"] = result[candidate]
                    break

        if "lineage" not in result.columns:
            for candidate in ["new_lineage", "cluster", "previous"]:
                if candidate in result.columns:
                    result["lineage"] = result[candidate]
                    break

        missing = {"ID", "lineage"}.difference(result.columns)
        if missing:
            raise ValueError(
                "Sequence data is missing required columns: "
                + ", ".join(sorted(missing))
            )

        result = self.clean_ids(result, "ID")
        result["lineage"] = result["lineage"].astype(str).str.strip()
        return result[["ID", "lineage"]].drop_duplicates("ID", keep="first")

    def normalize_assignments(self, dataframe):
        return self.normalize_seq_data(dataframe)

    def normalize_metadata(self, dataframe):
        result = dataframe.copy()

        if "ID" not in result.columns:
            for candidate in ["primary_accession", "id", "accession"]:
                if candidate in result.columns:
                    result["ID"] = result[candidate]
                    break

        if "ID" not in result.columns:
            raise ValueError(
                "Metadata must contain 'ID' or 'primary_accession'. "
                f"Available columns: {list(result.columns)}"
            )

        result = self.clean_ids(result, "ID")
        first = ["ID"]
        remaining = [column for column in result.columns if column != "ID"]
        return result[first + remaining].drop_duplicates("ID", keep="first")

    def load_core(self):
        if not self.core_script.exists():
            raise FileNotFoundError(
                f"Core merge script not found: {self.core_script}. "
                "Copy the current upstream MADDOG scripts/merge_results.py "
                "to merge_results_core.py."
            )

        core_directory = str(self.core_script.resolve().parent)
        if core_directory not in sys.path:
            sys.path.insert(0, core_directory)

        spec = spec_from_file_location("maddog_merge_results_core", self.core_script)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load core script: {self.core_script}")

        module = module_from_spec(spec)
        spec.loader.exec_module(module)

        if not hasattr(module, "run_postprocess"):
            raise AttributeError(
                f"{self.core_script} does not define run_postprocess()."
            )

        return module

    def prepare_inputs(self):
        self.outdir.mkdir(parents=True, exist_ok=True)
        prepared_dir = self.outdir / "prepared_inputs"
        prepared_dir.mkdir(parents=True, exist_ok=True)

        node_data = self.normalize_node_data(self.read_table(self.node_data))
        seq_data = self.normalize_seq_data(self.read_table(self.seq_data))
        metadata = self.normalize_metadata(self.read_table(self.metadata))
        assignments = self.normalize_assignments(
            self.read_table(self.assignments)
        )

        paths = {
            "node_data": prepared_dir / "node_data.tsv",
            "seq_data": prepared_dir / "seq_data.tsv",
            "metadata": prepared_dir / "metadata.tsv",
            "assignments": prepared_dir / "assignments.tsv",
        }

        self.write_table(node_data, paths["node_data"])
        self.write_table(seq_data, paths["seq_data"])
        self.write_table(metadata, paths["metadata"])
        self.write_table(assignments, paths["assignments"])

        return paths

    def write_results(self, result):
        output_fields = {
            "node_data": "node_data_final.tsv",
            "seq_data_updated": "seq_data_updated.tsv",
            "seq_data_with_country": "seq_data_with_country.tsv",
            "lineage_clusters_updated": "lineage_clusters_updated.tsv",
            "clades_df": "clades.tsv",
            "sequences": "sequences.tsv",
            "current": "current_lineage_nodes.tsv",
            "updates": "updates.tsv",
            "node_support_df": "node_support.tsv",
            "nodes_5_df": "nodes_5_to_9_tips.tsv",
            "relevant_lineages": "relevant_lineages.tsv",
            "lineage_info_updated": "lineage_info_updated.tsv",
            "sequence_data_final": "sequence_data_final.tsv",
            "tests_df": "tests.tsv",
            "noi_df": "nodes_of_interest.tsv",
            "lineage_node_summary": "lineage_node_summary.tsv",
        }

        written = []
        for attribute, filename in output_fields.items():
            dataframe = getattr(result, attribute, None)
            if isinstance(dataframe, pd.DataFrame):
                path = self.outdir / filename
                self.write_table(dataframe, path)
                written.append(path)

        mapping = getattr(result, "mapping", None)
        if isinstance(mapping, dict):
            mapping_df = pd.DataFrame(
                sorted(mapping.items()), columns=["lineage", "number"]
            )
            path = self.outdir / "lineage_number_mapping.tsv"
            self.write_table(mapping_df, path)
            written.append(path)

        return written

    def run(self):
        paths = self.prepare_inputs()
        core = self.load_core()

        result = core.run_postprocess(
            node_data_path=paths["node_data"],
            seq_data_path=paths["seq_data"],
            metadata_path=paths["metadata"],
            assignments_path=paths["assignments"],
            tree_path=self.tree,
            alignment_path=self.alignment,
            ancestral_path=self.ancestral,
            datasets_dir=self.datasets_dir,
            ref_lineage_path=self.ref_lineage,
            min_update_count=self.min_update_count,
            max_update_iter=self.max_update_iter,
        )

        written = self.write_results(result)
        print(f"Merge completed. Output directory: {self.outdir}")
        print(f"Wrote {len(written)} result tables.")


if __name__ == "__main__":
    parser = ArgumentParser(
        description=(
            "Normalize SeqDesignation outputs and run the current MADDOG "
            "merge_results.py implementation."
        )
    )
    parser.add_argument(
        "--core_script",
        default=str(Path(__file__).with_name("merge_results_core.py")),
        help=(
            "Path to the unchanged upstream MADDOG merge_results.py. "
            "Default: merge_results_core.py beside this script."
        ),
    )
    parser.add_argument("--node_data", "--node-data", required=True)
    parser.add_argument("--seq_data", "--seq-data", required=True)
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--assignments", required=True)
    parser.add_argument("--alignment", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--ancestral", default=None)
    parser.add_argument("--datasets_dir", "--datasets-dir", default="Datasets")
    parser.add_argument(
        "--ref_lineage",
        "--ref-lineage",
        default="inst/extdata/References/RABV/lineage_info.csv",
    )
    parser.add_argument("--outdir", default="merge_results_output")
    parser.add_argument("--min_update_count", type=int, default=10)
    parser.add_argument("--max_update_iter", type=int, default=100)

    args = parser.parse_args()

    runner = MergeResults(
        args.core_script,
        args.node_data,
        args.seq_data,
        args.metadata,
        args.assignments,
        args.alignment,
        args.tree,
        args.ancestral,
        args.datasets_dir,
        args.ref_lineage,
        args.outdir,
        args.min_update_count,
        args.max_update_iter,
    )
    runner.run()
