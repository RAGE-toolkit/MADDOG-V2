#!/usr/bin/env python3
"""
Assign MADDOG-style hierarchical lineage names to filtered internal nodes.

Expected node-table columns:
    node_id
    descendant_tip_labels

Recommended additional columns:
    Node
    descendant_tip_count or n_tips
    bootstrap

The node table should be the filtered output produced by AssignNodeDetails.py.
The metadata table must contain one sequence-ID column and one previous-lineage
column. Existing code and extra columns in both input tables are preserved.

Example:
    python seq_designation.py \
        --nodes tmp/NodeAssignment \
        --metadata rabv-complete-tree-metadata.tsv \
        --metadata_id_column ID \
        --previous_column previous \
        --node_output tmp/designated_nodes.tsv \
        --sequence_output tmp/sequence_designations.tsv
"""

from argparse import ArgumentParser
from pathlib import Path
import string

import pandas as pd


class SeqDesignation:
    def __init__(
        self,
        nodes,
        metadata,
        metadata_id_column,
        previous_column,
        major_clade_column,
        minor_clade_column,
        node_output,
        sequence_output,
        assignments_output,
        normalized_metadata_output,
        min_cluster_size,
        min_parent_tip_diff,
        lineage_separator,
        unassigned_label,
    ):
        self.nodes = nodes
        self.metadata = metadata
        self.metadata_id_column = metadata_id_column
        self.previous_column = previous_column
        self.major_clade_column = major_clade_column
        self.minor_clade_column = minor_clade_column
        self.node_output = node_output
        self.sequence_output = sequence_output
        self.assignments_output = assignments_output
        self.normalized_metadata_output = normalized_metadata_output
        self.min_cluster_size = min_cluster_size
        self.min_parent_tip_diff = min_parent_tip_diff
        self.lineage_separator = lineage_separator
        self.unassigned_label = unassigned_label

    def read_table(self, path):
        """
        Read CSV, TSV, or whitespace-delimited tables.

        The first successful parse producing more than one column is used.
        """
        path = Path(path)

        attempts = []

        if str(path).lower().endswith(".csv"):
            attempts.append({"sep": ","})

        attempts.extend(
            [
                {"sep": "\t"},
                {"sep": None, "engine": "python"},
                {"sep": r"\s+", "engine": "python"},
                {"sep": ","},
            ]
        )

        errors = []

        for options in attempts:
            try:
                dataframe = pd.read_csv(
                    path,
                    dtype=str,
                    keep_default_na=False,
                    **options,
                )

                dataframe.columns = [
                    str(column).strip()
                    for column in dataframe.columns
                ]

                if len(dataframe.columns) > 1:
                    return dataframe

            except (pd.errors.ParserError, UnicodeDecodeError, ValueError) as error:
                errors.append(str(error))

        raise ValueError(
            f"Could not determine the delimiter for input table: {path}. "
            "Expected comma, tab, or whitespace-separated columns. "
            f"Last parser errors: {' | '.join(errors[-3:])}"
        )

    def prepare_metadata(self, metadata):
        """
        Prepare metadata for designation.

        When --previous_column is absent or not present, combine
        major_clade and minor_clade into a temporary 'previous' column.
        """
        result = metadata.copy()

        if self.metadata_id_column not in result.columns:
            raise ValueError(
                f"Metadata ID column '{self.metadata_id_column}' was not found. "
                f"Available columns: {', '.join(map(str, result.columns))}"
            )

        result[self.metadata_id_column] = (
            result[self.metadata_id_column].astype(str).str.strip()
        )

        # Remove rows with missing placeholder IDs. These commonly arise from
        # blank lines, extra delimiters, or spreadsheet-exported empty rows.
        invalid_ids = {"", "none", "nan", "na", "null"}
        valid_id_mask = ~result[self.metadata_id_column].str.lower().isin(
            invalid_ids
        )
        result = result.loc[valid_id_mask].copy()

        use_existing_previous = (
            self.previous_column is not None
            and self.previous_column in result.columns
        )

        if use_existing_previous:
            result[self.previous_column] = (
                result[self.previous_column].astype(str).str.strip()
            )
            return result

        required = {
            self.major_clade_column,
            self.minor_clade_column,
        }
        missing = required.difference(result.columns)

        if missing:
            raise ValueError(
                "Metadata must contain either --previous_column or both "
                "--major_clade_column and --minor_clade_column. Missing: "
                + ", ".join(sorted(missing))
                + ". Available columns: "
                + ", ".join(map(str, result.columns))
            )

        major = result[self.major_clade_column].astype(str).str.strip()
        minor = result[self.minor_clade_column].astype(str).str.strip()

        result["previous"] = (
            major.str.cat(minor, sep=" ").str.replace(
                r"\s+",
                " ",
                regex=True,
            ).str.strip()
        )

        self.previous_column = "previous"
        return result

    def write_table(self, dataframe, path):
        output_path = Path(path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if str(output_path).lower().endswith(".csv"):
            dataframe.to_csv(output_path, index=False, na_rep="NA")
        else:
            dataframe.to_csv(output_path, sep="\t", index=False, na_rep="NA")

    def tip_set(self, value):
        if pd.isna(value) or str(value).strip() == "":
            return set()

        return {
            tip.strip()
            for tip in str(value).split(",")
            if tip.strip()
        }

    def validate_inputs(self, nodes, metadata):
        required_node_columns = {"node_id", "descendant_tip_labels"}
        missing_node_columns = required_node_columns.difference(nodes.columns)

        if missing_node_columns:
            raise ValueError(
                "Node table is missing required columns: "
                + ", ".join(sorted(missing_node_columns))
            )

        required_metadata_columns = {
            self.metadata_id_column,
            self.previous_column,
        }
        missing_metadata_columns = required_metadata_columns.difference(
            metadata.columns
        )

        if missing_metadata_columns:
            raise ValueError(
                "Metadata table is missing required columns: "
                + ", ".join(sorted(missing_metadata_columns))
            )

        if nodes["node_id"].duplicated().any():
            duplicated = nodes.loc[
                nodes["node_id"].duplicated(keep=False), "node_id"
            ].astype(str).tolist()
            raise ValueError(
                "node_id values must be unique. Duplicates: "
                + ", ".join(duplicated[:10])
            )

        duplicate_mask = metadata[self.metadata_id_column].duplicated(
            keep=False
        )

        if duplicate_mask.any():
            duplicated = (
                metadata.loc[duplicate_mask, self.metadata_id_column]
                .astype(str)
                .tolist()
            )
            raise ValueError(
                f"Metadata column '{self.metadata_id_column}' must be unique. "
                "Genuine duplicate IDs: " + ", ".join(duplicated[:10])
            )

    def prepare_nodes(self, nodes):
        result = nodes.copy()
        result["node_id"] = result["node_id"].astype(str)
        result["tip_set"] = result["descendant_tip_labels"].apply(self.tip_set)
        result["descendant_tip_count"] = result["tip_set"].apply(len)

        if "Node" in result.columns:
            result["Node_sort"] = pd.to_numeric(result["Node"], errors="coerce")
        else:
            result["Node_sort"] = pd.NA

        return result

    def selected_parent_map(self, nodes):
        """Find the closest selected ancestral node using tip-set inclusion."""
        tip_sets = dict(zip(nodes["node_id"], nodes["tip_set"]))
        parent_map = {}

        for child_id, child_tips in tip_sets.items():
            possible_parents = []

            for parent_id, parent_tips in tip_sets.items():
                if parent_id == child_id:
                    continue

                if child_tips < parent_tips:
                    possible_parents.append((len(parent_tips), parent_id))

            if possible_parents:
                possible_parents.sort(key=lambda value: (value[0], value[1]))
                parent_map[child_id] = possible_parents[0][1]
            else:
                parent_map[child_id] = ""

        return parent_map

    def add_relationships(self, nodes):
        result = nodes.copy()
        parent_map = self.selected_parent_map(result)
        tip_count_map = dict(
            zip(result["node_id"], result["descendant_tip_count"])
        )

        children_by_parent = {}
        for child_id, parent_id in parent_map.items():
            if parent_id:
                children_by_parent.setdefault(parent_id, []).append(child_id)

        descendant_selected_count = {}
        for node_id in result["node_id"]:
            descendants = set()
            stack = list(children_by_parent.get(node_id, []))

            while stack:
                child_id = stack.pop()
                if child_id in descendants:
                    continue
                descendants.add(child_id)
                stack.extend(children_by_parent.get(child_id, []))

            descendant_selected_count[node_id] = len(descendants)

        result["direct_parent_overlap_node"] = result["node_id"].map(parent_map)
        result["overlaps"] = result["node_id"].map(descendant_selected_count)
        result["parent_child_tip_difference"] = result.apply(
            lambda row: (
                tip_count_map[row["direct_parent_overlap_node"]]
                - row["descendant_tip_count"]
                if row["direct_parent_overlap_node"]
                else pd.NA
            ),
            axis=1,
        )

        return result

    def assignment_order(self, nodes):
        result = nodes.copy()
        result = result.sort_values(
            by=["overlaps", "descendant_tip_count", "Node_sort", "node_id"],
            ascending=[False, False, True, True],
            kind="mergesort",
            na_position="last",
        )
        return result

    def add_exclusive_tip_assignment(self, nodes):
        """Assign each tip to the deepest surviving selected node."""
        result = self.add_relationships(nodes)
        ordered_nodes = self.assignment_order(result)
        tip_to_node = {}

        # Parent nodes are visited first. Descendants overwrite them later.
        for _, row in ordered_nodes.iterrows():
            for tip in row["tip_set"]:
                tip_to_node[tip] = row["node_id"]

        result["exclusive_tip_labels"] = result["node_id"].apply(
            lambda node_id: ",".join(
                sorted(
                    tip
                    for tip, assigned_node in tip_to_node.items()
                    if assigned_node == node_id
                )
            )
        )
        result["exclusive_tip_count"] = result["exclusive_tip_labels"].apply(
            lambda value: 0 if value == "" else len(value.split(","))
        )

        return result, tip_to_node

    def remove_small_clusters(self, nodes):
        result = nodes.copy()

        while True:
            if result.empty:
                return result

            result, _ = self.add_exclusive_tip_assignment(result)
            keep = result["exclusive_tip_count"] >= self.min_cluster_size

            if keep.all():
                return result

            result = result.loc[keep].copy()

    def remove_nearly_identical_children(self, nodes):
        """Remove nested children adding too few tips relative to their parent."""
        result = self.add_relationships(nodes)
        difference = pd.to_numeric(
            result["parent_child_tip_difference"], errors="coerce"
        )
        has_parent = result["direct_parent_overlap_node"].astype(str) != ""
        remove = has_parent & difference.notna() & (
            difference < self.min_parent_tip_diff
        )

        return result.loc[~remove].copy()

    def prune_nodes(self, nodes):
        result = self.remove_small_clusters(nodes)
        result = self.remove_nearly_identical_children(result)
        # Removing near-identical children changes exclusive assignments.
        result = self.remove_small_clusters(result)
        result, _ = self.add_exclusive_tip_assignment(result)
        return result

    def previous_assignment_map(self, metadata):
        clean_metadata = metadata.copy()
        clean_metadata[self.metadata_id_column] = clean_metadata[
            self.metadata_id_column
        ].astype(str)

        return dict(
            zip(
                clean_metadata[self.metadata_id_column],
                clean_metadata[self.previous_column],
            )
        )

    def add_previous_assignments(self, nodes, metadata):
        result = nodes.copy()
        previous_map = self.previous_assignment_map(metadata)
        previous_values = []
        previous_counts = []

        for tips in result["tip_set"]:
            values = []
            for tip in sorted(tips):
                value = previous_map.get(tip)
                if pd.isna(value) or str(value).strip() == "":
                    continue
                value = str(value).strip()
                if value not in values:
                    values.append(value)

            previous_values.append(",".join(values))
            previous_counts.append(len(values))

        result["previous"] = previous_values
        result["previous_assignment_count"] = previous_counts
        result["mixed_previous_assignments"] = (
            result["previous_assignment_count"] > 1
        )

        return result

    def excel_letters(self, index):
        """1 -> A, 26 -> Z, 27 -> AA."""
        if index < 1:
            raise ValueError("Lineage letter index must be at least 1")

        letters = ""
        current = index
        while current:
            current, remainder = divmod(current - 1, 26)
            letters = string.ascii_uppercase[remainder] + letters
        return letters

    def root_prefix(self, previous):
        previous = str(previous).strip()
        if previous == "":
            return self.unassigned_label
        return previous

    def child_sort_key(self, row):
        node_value = pd.to_numeric(pd.Series([row.get("Node_sort")]), errors="coerce").iloc[0]
        if pd.isna(node_value):
            node_value = float("inf")
        return (-int(row["descendant_tip_count"]), node_value, row["node_id"])

    def assign_lineage_names(self, nodes):
        result = self.add_relationships(nodes)
        node_rows = {row["node_id"]: row for _, row in result.iterrows()}
        node_ids = set(node_rows)
        children_by_parent = {}

        for _, row in result.iterrows():
            parent_id = row["direct_parent_overlap_node"]
            if parent_id in node_ids:
                children_by_parent.setdefault(parent_id, []).append(row["node_id"])

        for parent_id in children_by_parent:
            children_by_parent[parent_id].sort(
                key=lambda node_id: self.child_sort_key(node_rows[node_id])
            )

        roots_by_previous = {}
        for _, row in result.iterrows():
            parent_id = row["direct_parent_overlap_node"]
            parent_is_selected = parent_id in node_ids
            parent_has_same_previous = False

            if parent_is_selected:
                parent_has_same_previous = (
                    node_rows[parent_id]["previous"] == row["previous"]
                )

            if not parent_is_selected or not parent_has_same_previous:
                previous = row["previous"]
                roots_by_previous.setdefault(previous, []).append(row["node_id"])

        for previous in roots_by_previous:
            roots_by_previous[previous].sort(
                key=lambda node_id: self.child_sort_key(node_rows[node_id])
            )

        lineage_map = {}

        for previous, roots in sorted(roots_by_previous.items()):
            prefix = self.root_prefix(previous)

            for root_index, root_id in enumerate(roots, start=1):
                letter = self.excel_letters(root_index)
                root_lineage = (
                    f"{prefix}{self.lineage_separator}{letter}1"
                    if prefix
                    else f"{letter}1"
                )
                lineage_map[root_id] = root_lineage

                stack = [root_id]
                while stack:
                    parent_id = stack.pop()
                    parent_lineage = lineage_map[parent_id]
                    children = children_by_parent.get(parent_id, [])

                    same_previous_children = [
                        child_id
                        for child_id in children
                        if node_rows[child_id]["previous"]
                        == node_rows[parent_id]["previous"]
                    ]

                    for child_index, child_id in enumerate(
                        same_previous_children, start=1
                    ):
                        lineage_map[child_id] = (
                            f"{parent_lineage}.{child_index}"
                        )

                    # Reverse push keeps processing order deterministic.
                    stack.extend(reversed(same_previous_children))

        result["lineage"] = result["node_id"].map(lineage_map).fillna("")
        return result

    def validate_lineages(self, nodes):
        missing = nodes["lineage"].astype(str).str.strip() == ""
        if missing.any():
            missing_nodes = nodes.loc[missing, "node_id"].astype(str).tolist()
            raise ValueError(
                "No lineage was assigned to nodes: "
                + ", ".join(missing_nodes[:20])
            )

        duplicated = nodes["lineage"].duplicated(keep=False)
        if duplicated.any():
            duplicate_names = sorted(
                nodes.loc[duplicated, "lineage"].astype(str).unique().tolist()
            )
            raise ValueError(
                "Duplicate lineage names were produced: "
                + ", ".join(duplicate_names[:20])
            )

    def add_merge_numbers(self, nodes):
        """Assign stable temporary cluster numbers required by merge_results.py."""
        result = nodes.copy()

        sort_columns = []
        ascending = []

        if "Node_sort" in result.columns:
            sort_columns.append("Node_sort")
            ascending.append(True)

        sort_columns.append("node_id")
        ascending.append(True)

        ordered = result.sort_values(
            by=sort_columns,
            ascending=ascending,
            kind="mergesort",
            na_position="last",
        )

        number_map = {
            node_id: str(index)
            for index, node_id in enumerate(ordered["node_id"], start=1)
        }
        result["number"] = result["node_id"].map(number_map)
        return result

    def build_sequence_output(self, nodes, metadata):
        """Build the exact ID/lineage table consumed by merge_results.py."""
        _, tip_to_node = self.add_exclusive_tip_assignment(nodes)
        lineage_map = dict(zip(nodes["node_id"], nodes["lineage"]))

        metadata_ids = metadata[self.metadata_id_column].astype(str)
        assigned_nodes = metadata_ids.map(tip_to_node)
        new_lineages = assigned_nodes.map(lineage_map)
        final_lineages = new_lineages.fillna(metadata[self.previous_column])

        sequence_output = pd.DataFrame(
            {
                "ID": metadata_ids,
                "lineage": final_lineages.astype(str),
            }
        )
        sequence_output = sequence_output.loc[
            sequence_output["ID"].astype(str).str.strip() != ""
        ].copy()
        sequence_output = sequence_output.drop_duplicates(
            subset=["ID"], keep="first"
        )

        return sequence_output

    def build_assignments_output(self, metadata):
        """Build the existing ID/lineage assignments expected by merge_results.py."""
        assignments = pd.DataFrame(
            {
                "ID": metadata[self.metadata_id_column].astype(str),
                "lineage": metadata[self.previous_column].astype(str),
            }
        )
        assignments = assignments.loc[
            assignments["ID"].astype(str).str.strip() != ""
        ].copy()
        return assignments.drop_duplicates(subset=["ID"], keep="first")

    def build_normalized_metadata(self, metadata):
        """Preserve metadata while ensuring the merge-required ID column exists."""
        result = metadata.copy()
        result["ID"] = result[self.metadata_id_column].astype(str)

        preferred = ["ID"]
        remaining = [column for column in result.columns if column != "ID"]
        return result[preferred + remaining]

    def clean_node_output(self, nodes):
        """Build a merge-compatible node table while retaining diagnostic columns."""
        result = nodes.copy()
        result["descendant_tip_labels"] = result["tip_set"].apply(
            lambda tips: ",".join(sorted(tips))
        )

        if "Node" in result.columns:
            result["node"] = pd.to_numeric(result["Node"], errors="coerce")
        elif "node" not in result.columns:
            raise ValueError(
                "The filtered node table must contain numeric 'Node' values "
                "for merge_results.py compatibility."
            )

        required_first = ["node", "lineage", "number"]
        remaining = [
            column
            for column in result.columns
            if column not in required_first + ["tip_set", "Node_sort"]
        ]
        return result[required_first + remaining]

    def run(self):
        nodes = self.read_table(self.nodes)
        metadata = self.read_table(self.metadata)
        metadata = self.prepare_metadata(metadata)
        self.validate_inputs(nodes, metadata)

        nodes = self.prepare_nodes(nodes)
        nodes = self.prune_nodes(nodes)
        nodes = self.add_previous_assignments(nodes, metadata)
        nodes = self.assign_lineage_names(nodes)
        self.validate_lineages(nodes)
        nodes = self.add_merge_numbers(nodes)

        sequence_output = self.build_sequence_output(nodes, metadata)
        assignments_output = self.build_assignments_output(metadata)
        normalized_metadata = self.build_normalized_metadata(metadata)
        node_output = self.clean_node_output(nodes)

        self.write_table(node_output, self.node_output)
        self.write_table(sequence_output, self.sequence_output)

        if self.assignments_output:
            self.write_table(assignments_output, self.assignments_output)

        if self.normalized_metadata_output:
            self.write_table(normalized_metadata, self.normalized_metadata_output)

        print(f"Wrote merge-compatible node data to: {self.node_output}")
        print(f"Wrote merge-compatible sequence data to: {self.sequence_output}")
        if self.assignments_output:
            print(f"Wrote existing assignments to: {self.assignments_output}")
        if self.normalized_metadata_output:
            print(f"Wrote normalized metadata to: {self.normalized_metadata_output}")
        print(f"Surviving selected nodes: {len(node_output)}")


if __name__ == "__main__":
    parser = ArgumentParser(
        description=(
            "Assign MADDOG-style hierarchical lineage names to a filtered "
            "internal-node table."
        )
    )
    parser.add_argument(
        "--nodes",
        required=True,
        help="Filtered node table from AssignNodeDetails.py.",
    )
    parser.add_argument(
        "--metadata",
        required=True,
        help="CSV or TSV containing sequence IDs and previous assignments.",
    )
    parser.add_argument(
        "--metadata_id_column",
        default="primary_accession",
        help=(
            "Metadata sequence-ID column. "
            "Default: primary_accession"
        ),
    )
    parser.add_argument(
        "--previous_column",
        default=None,
        help=(
            "Optional existing combined lineage column. When omitted, "
            "major_clade and minor_clade are combined."
        ),
    )
    parser.add_argument(
        "--major_clade_column",
        default="major_clade",
        help="Major-clade metadata column. Default: major_clade",
    )
    parser.add_argument(
        "--minor_clade_column",
        default="minor_clade",
        help="Minor-clade metadata column. Default: minor_clade",
    )
    parser.add_argument(
        "--node_output",
        default="designated_nodes.tsv",
        help="Output table for selected nodes and their new lineages.",
    )
    parser.add_argument(
        "--sequence_output",
        default="sequence_designations.tsv",
        help="Merge-compatible sequence table containing ID and lineage.",
    )
    parser.add_argument(
        "--assignments_output",
        default=None,
        help=(
            "Optional output containing existing ID/lineage assignments for "
            "merge_results.py."
        ),
    )
    parser.add_argument(
        "--normalized_metadata_output",
        default=None,
        help=(
            "Optional metadata output preserving all columns and adding the "
            "required ID column."
        ),
    )
    parser.add_argument(
        "--min_cluster_size",
        type=int,
        default=2,
        help="Minimum uniquely assigned tips per selected node. Default: 2",
    )
    parser.add_argument(
        "--min_parent_tip_diff",
        type=int,
        default=5,
        help=(
            "Minimum parent-minus-child descendant-tip difference required "
            "to retain a nested child. Default: 5"
        ),
    )
    parser.add_argument(
        "--lineage_separator",
        default="_",
        help="Separator between previous lineage and new suffix. Default: _",
    )
    parser.add_argument(
        "--unassigned_label",
        default="Unassigned",
        help="Prefix for nodes without a previous assignment.",
    )

    args = parser.parse_args()

    designation = SeqDesignation(
        args.nodes,
        args.metadata,
        args.metadata_id_column,
        args.previous_column,
        args.major_clade_column,
        args.minor_clade_column,
        args.node_output,
        args.sequence_output,
        args.assignments_output,
        args.normalized_metadata_output,
        args.min_cluster_size,
        args.min_parent_tip_diff,
        args.lineage_separator,
        args.unassigned_label,
    )
    designation.run()
