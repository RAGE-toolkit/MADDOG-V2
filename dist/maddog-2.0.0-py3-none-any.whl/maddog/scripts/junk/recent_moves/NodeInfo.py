#!/usr/bin/env python3
"""
node_info.py

A Python port of the key logic in:
MADDOG/R/node_info_nolength.R

Usage:
  python node_info.py \
    --contree Example_designation_combined_aligned.fasta.contree \
    --aligned_fasta Example_designation_combined_aligned.fasta \
    --metadata Example_designation_combined_metadata.csv \
    --ancestral ancestral_sequences.fasta \
    --bootstrap 95 \
    --min_tips 10 \
    --min_cluster_size 2
"""

from __future__ import annotations

import argparse
import re
import string
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import numpy as np
import pandas as pd
from Bio import Phylo, SeqIO


# ---------------------------------------------------------------------------
# ContreeNodeMapper
# ---------------------------------------------------------------------------

class ContreeNodeMapper:
    def __init__(
        self,
        contree_path: str,
        *,
        digits: int = 7,
        order: str = "postorder",
        support_mode: str = "ufboot",
    ) -> None:
        self.contree_path = contree_path
        self.digits = digits
        self.order = order
        self.support_mode = support_mode
        self._tree = None
        self._internals_cache = None
        self._clade_to_pos_cache = None

    # ------------------------------------------------------------------ tree I/O

    def _internals_ape(self):
        """Return internal nodes in ape-style preorder (cached)."""
        if self._internals_cache is None:
            tree = self.load_tree()
            self._internals_cache = tree.get_nonterminals(order="preorder")
            self._clade_to_pos_cache = {
                id(cl): (i0 + 1) for i0, cl in enumerate(self._internals_cache)
            }
        return self._internals_cache

    def load_tree(self):
        if self._tree is None:
            self._tree = Phylo.read(self.contree_path, "newick")
        return self._tree

    @staticmethod
    def fasta_to_dict(fasta_path: str) -> Dict[str, str]:
        return {rec.id: str(rec.seq) for rec in SeqIO.parse(fasta_path, "fasta")}

    @staticmethod
    def load_metadata(csv_path: str) -> pd.DataFrame:
        md = pd.read_csv(csv_path)
        if "ID" not in md.columns or "year" not in md.columns:
            raise ValueError("Metadata must contain columns: ID, year")
        return md

    @staticmethod
    def build_seq_data_from_fasta(fasta_path: str) -> pd.DataFrame:
        records = list(SeqIO.parse(fasta_path, "fasta"))
        if not records:
            raise ValueError(f"No sequences found in FASTA: {fasta_path}")
        length_before = len(str(records[0].seq))
        rows = []
        for rec in records:
            seq = str(rec.seq)
            n_count = seq.count("n")
            gap_count = seq.count("-")
            length_after = length_before - n_count - gap_count
            rows.append(
                {
                    "ID": rec.id,
                    "N": n_count,
                    "gap": gap_count,
                    "Length_before": length_before,
                    "Length_after": length_after,
                }
            )
        return pd.DataFrame(rows)

    @staticmethod
    def add_year_to_seq_data(
        seq_data: pd.DataFrame, metadata: pd.DataFrame
    ) -> pd.DataFrame:
        year_map = metadata.set_index("ID")["year"]
        out = seq_data.copy()
        out["Year"] = out["ID"].map(year_map)
        return out

    # ------------------------------------------------------------------ bootstrap

    def _parse_support_label(
        self, raw: Optional[str]
    ) -> Tuple[Optional[float], Optional[str]]:
        if raw is None:
            return None, None
        s = str(raw).strip()
        if s == "":
            return None, s
        if self.support_mode in ("ufboot", "first") and "/" in s:
            parts = s.split("/")
            idx = 1 if self.support_mode == "ufboot" else 0
            if len(parts) > idx:
                try:
                    return float(parts[idx]), s
                except Exception:
                    return None, s
        try:
            return float(s), s
        except Exception:
            return None, s

    def _get_bootstrap(self, clade) -> Tuple[Optional[float], Optional[str]]:
        name = getattr(clade, "name", None)
        conf = getattr(clade, "confidence", None)
        if name is not None and str(name).strip() != "":
            return self._parse_support_label(name)
        if conf is not None:
            try:
                return float(conf), str(conf)
            except Exception:
                return None, str(conf)
        return None, None

    # ------------------------------------------------------------------ node selection

    def build_node_data(self, *, threshold: float = 70.0) -> pd.DataFrame:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        rows: List[Dict[str, Any]] = []
        for i0, clade in enumerate(internals):
            internal_pos = i0 + 1
            ape_node = ntips + internal_pos
            bootstrap, _ = self._get_bootstrap(clade)
            if bootstrap is None or bootstrap < threshold:
                continue
            rows.append({"Node": ape_node, "bootstrap": float(bootstrap), "n_tips": pd.NA})
        return pd.DataFrame(rows)

    def add_tip_counts_and_filter(
        self,
        node_data: pd.DataFrame,
        *,
        min_tips: int = 10,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        node_data = node_data.copy()
        n_tips_list: List[Optional[int]] = []
        for ape_node in node_data["Node"].astype(int).tolist():
            internal_pos = int(ape_node) - ntips
            if internal_pos < 1 or internal_pos > len(internals):
                n_tips_list.append(None)
                continue
            clade = internals[internal_pos - 1]
            n_tips_list.append(len(clade.get_terminals()))
        node_data["n_tips"] = pd.array(n_tips_list, dtype="Int64")
        nodes_5 = node_data.loc[
            node_data["n_tips"].notna() & (node_data["n_tips"] >= min_tips)
        ].reset_index(drop=True)
        return node_data, nodes_5

    def add_clade_tip_labels(
        self, nodes_df: pd.DataFrame, *, node_col: str = "Node"
    ) -> pd.DataFrame:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        out = nodes_df.copy()
        tip_lists: List[str] = []
        tip_counts: List[Optional[int]] = []
        for ape_node in out[node_col].astype(int).tolist():
            internal_pos = ape_node - ntips
            if internal_pos < 1 or internal_pos > len(internals):
                tip_lists.append("")
                tip_counts.append(None)
                continue
            clade = internals[internal_pos - 1]
            tips = [t.name for t in clade.get_terminals() if getattr(t, "name", None)]
            tip_lists.append(",".join(tips))
            tip_counts.append(len(tips))
        out["tip_labels"] = tip_lists
        out["tip_count_from_labels"] = pd.array(tip_counts, dtype="Int64")
        return out

    # ------------------------------------------------------------------ diff_count

    @staticmethod
    def ancestor_diff_positions_all(
        ancestral_dict: Dict[str, str], ancestor_key: str, tip_keys: List[str]
    ) -> set:
        anc = ancestral_dict[ancestor_key]
        tips = [ancestral_dict[t] for t in tip_keys if t in ancestral_dict]
        if not tips:
            return set()
        x = {i for i, (a, b) in enumerate(zip(anc, tips[0])) if a != b}
        for tip_seq in tips[1:]:
            x &= {i for i, (a, b) in enumerate(zip(anc, tip_seq)) if a != b}
            if not x:
                break
        return x

    def compare_nodes(
        self,
        nodes_5: pd.DataFrame,
        ancestral_dict: Dict[str, str],
    ) -> Tuple[pd.DataFrame, Dict[str, List[str]], Dict[str, List[str]]]:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        out = nodes_5.copy()
        out["NODE_key"] = (
            (out["Node"].astype(int) - (1 + ntips))
            .apply(lambda x: f"NODE_{x:07d}")
        )
        out["diff_count"] = 0
        node_to_alltips: Dict[str, List[str]] = {}
        node_to_ancestral_tips: Dict[str, List[str]] = {}

        for i, row in out.iterrows():
            ancestor_key = row["NODE_key"]
            tips_str = row.get("tip_labels", "")
            tip_list_all = [t.strip() for t in tips_str.split(",") if t.strip()] if tips_str else []
            node_to_alltips[ancestor_key] = tip_list_all
            node_to_ancestral_tips[ancestor_key] = tip_list_all
            tip_keys = [t for t in tip_list_all if t in ancestral_dict]
            if ancestor_key in ancestral_dict and tip_keys:
                diff_pos = self.ancestor_diff_positions_all(ancestral_dict, ancestor_key, tip_keys)
                out.at[i, "diff_count"] = len(diff_pos)
            else:
                out.at[i, "diff_count"] = 0

        return out, node_to_alltips, node_to_ancestral_tips

    # ------------------------------------------------------------------ overlaps (R-style)

    def compute_overlaps_rstyle(
        self, nodes_df: pd.DataFrame, *, node_col: str = "Node"
    ) -> pd.Series:
        """
        overlaps[i] = number of selected internal nodes that are strict descendants of node i.
        Mirrors R: length(which(allDescendants(tree)[[node_i]] %in% nodes_df$Node))
        """
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        selected_nodes = set(nodes_df[node_col].astype(int).tolist())
        clade_to_pos = {id(cl): i0 + 1 for i0, cl in enumerate(internals)}

        def node_to_clade(ape_node: int):
            ip = ape_node - ntips
            if ip < 1 or ip > len(internals):
                return None
            return internals[ip - 1]

        overlaps: List[int] = []
        for ape_node in nodes_df[node_col].astype(int).tolist():
            clade = node_to_clade(ape_node)
            if clade is None:
                overlaps.append(0)
                continue
            subtree_internals = clade.get_nonterminals(order="preorder")
            cnt = 0
            for d in subtree_internals[1:]:  # exclude self
                pos = clade_to_pos.get(id(d))
                if pos is None:
                    continue
                if (ntips + pos) in selected_nodes:
                    cnt += 1
            overlaps.append(cnt)

        return pd.Series(overlaps, index=nodes_df.index, dtype="int64")

    # ------------------------------------------------------------------ clustering

    def assign_lineages_from_overlapping_nodes(
        self,
        nodes_diff: pd.DataFrame,
        node_to_tips: Dict[str, List[str]],
        all_tips: List[str],
        *,
        min_cluster_size: int = 2,
        node_key_col: str = "NODE_key",
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        lineage_assignments = pd.DataFrame({"tip": all_tips, "cluster": pd.NA})

        def recompute(nd: pd.DataFrame):
            nd = nd.sort_values("overlaps", ascending=False, kind="mergesort").copy()
            nd["cluster"] = range(1, len(nd) + 1)
            la = lineage_assignments.copy()
            la["cluster"] = pd.NA
            for _, row in nd.iterrows():
                node_key = row[node_key_col]
                cluster_id = int(row["cluster"])
                tips = node_to_tips.get(node_key, [])
                if tips:
                    la.loc[la["tip"].isin(tips), "cluster"] = cluster_id
            summary = (
                la.dropna(subset=["cluster"])
                .groupby("cluster", as_index=False)
                .size()
                .rename(columns={"size": "count"})
            )
            all_clusters = pd.DataFrame({"cluster": nd["cluster"].tolist()})
            summary = all_clusters.merge(summary, on="cluster", how="left").fillna({"count": 0})
            summary["count"] = summary["count"].astype(int)
            return nd, la, summary

        nd, la, summary = recompute(nodes_diff)
        while not summary.empty and summary["count"].min() < min_cluster_size:
            bad_clusters = set(summary.loc[summary["count"] < min_cluster_size, "cluster"].tolist())
            nd = nd.loc[~nd["cluster"].isin(bad_clusters)].copy()
            nd, la, summary = recompute(nd)

        return nd, la, summary

    # ------------------------------------------------------------------ issues table

    def build_issues_table_rstyle(
        self,
        nodes_diff: pd.DataFrame,
        *,
        node_col: str = "Node",
        n_tips_col: str = "n_tips",
        cluster_col: str = "cluster",
    ) -> pd.DataFrame:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        cladeid_to_pos = {id(cl): (i0 + 1) for i0, cl in enumerate(internals)}

        parent_of: Dict[int, int] = {}
        for parent in tree.find_clades(order="preorder"):
            for child in getattr(parent, "clades", []):
                parent_of[id(child)] = id(parent)

        ape_parent: Dict[int, Optional[int]] = {}
        for i0, cl in enumerate(internals):
            ape_node = ntips + (i0 + 1)
            pid = parent_of.get(id(cl))
            while pid is not None and pid not in cladeid_to_pos:
                pid = parent_of.get(pid)
            ape_parent[ape_node] = None if pid is None else ntips + cladeid_to_pos[pid]

        def internal_ancestors(ape_node: int) -> List[int]:
            out: List[int] = []
            cur = int(ape_node)
            while True:
                p = ape_parent.get(cur)
                if p is None:
                    break
                out.append(p)
                cur = p
            return out

        issues = nodes_diff[[node_col, n_tips_col, cluster_col]].copy()
        issues = issues.sort_values(cluster_col, ascending=True, kind="mergesort").reset_index(drop=True)
        node_list = issues[node_col].astype(int).tolist()
        node_set = set(node_list)
        issues["parent"] = ""

        for i in range(1, len(issues)):
            node_i = int(issues.at[i, node_col])
            anc = internal_ancestors(node_i)
            anc_in_issues = [a for a in anc if a in node_set]
            if not anc_in_issues:
                issues.at[i, "parent"] = ""
                continue
            anc_clusters = issues.loc[
                issues[node_col].astype(int).isin(anc_in_issues), cluster_col
            ].tolist()
            try:
                issues.at[i, "parent"] = int(anc_clusters[-1])
            except Exception:
                issues.at[i, "parent"] = ""

        def _pkey(x):
            if x == "" or pd.isna(x):
                return -1
            try:
                return int(x)
            except Exception:
                return -1

        issues["_pkey"] = issues["parent"].map(_pkey)
        issues = (
            issues.sort_values("_pkey", ascending=False, kind="mergesort")
            .drop(columns="_pkey")
            .reset_index(drop=True)
        )
        issues["number"] = pd.NA
        return issues

    # ------------------------------------------------------------------ tip helpers

    def _tips_for_ape_node(self, ape_node: int) -> List[str]:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        internal_pos = int(ape_node) - ntips
        if internal_pos < 1 or internal_pos > len(internals):
            return []
        clade = internals[internal_pos - 1]
        return [t.name for t in clade.get_terminals() if getattr(t, "name", None)]

    def _descendant_tips_for_ape_node(self, ape_node: int) -> List[str]:
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        internal_pos = int(ape_node) - ntips
        if internal_pos < 1 or internal_pos > len(internals):
            return []
        all_tips = [t.name for t in tree.get_terminals() if getattr(t, "name", None)]
        tip_rank = {name: i for i, name in enumerate(all_tips)}
        clade = internals[internal_pos - 1]
        tips = [t.name for t in clade.get_terminals() if getattr(t, "name", None)]
        tips.sort(key=lambda x: tip_rank.get(x, 10**12))
        return tips

    def _internal_descendants_ape(
        self, ape_node: int, *, include_self: bool = False
    ) -> List[int]:
        """
        Return ape-style node numbers of internal descendants.
        include_self=False mirrors R's descendants(..., type='all', ignore.tip=TRUE)
        which does NOT include the node itself.
        """
        tree = self.load_tree()
        ntips = len(tree.get_terminals())
        internals = self._internals_ape()
        internal_pos = int(ape_node) - ntips
        if internal_pos < 1 or internal_pos > len(internals):
            return []
        clade_to_pos = {id(cl): (i0 + 1) for i0, cl in enumerate(internals)}
        clade = internals[internal_pos - 1]
        sub_internals = clade.get_nonterminals(order="preorder")  # self is first
        out: List[int] = []
        for k, cl in enumerate(sub_internals):
            if k == 0 and not include_self:
                continue
            pos = clade_to_pos.get(id(cl))
            if pos is None:
                continue
            out.append(ntips + pos)
        return out

    # ------------------------------------------------------------------ prune & reassign

    def prune_by_parent_tip_difference_and_reassign(
        self,
        issues: pd.DataFrame,
        nodes_diff: pd.DataFrame,
        lineage_assignments: pd.DataFrame,
        seq_data: pd.DataFrame,
        metadata: pd.DataFrame,
        *,
        parent_max: int = 1000,
        min_parent_tip_diff: int = 5,
        node_col: Optional[str] = None,
        cluster_col: str = "cluster",
        parent_col: str = "parent",
        n_tips_col: str = "n_tips",
        tip_labels_col: str = "tip_labels",
        la_tip_col: str = "tip",
        la_cluster_col: str = "cluster",
        seq_id_col: str = "ID",
        metadata_assignment_col: str = "assignment",
    ) -> Tuple[
        pd.DataFrame, pd.DataFrame, pd.DataFrame,
        pd.DataFrame, pd.DataFrame, pd.DataFrame
    ]:
        issues = issues.copy()
        nodes_diff = nodes_diff.copy()
        lineage_assignments = lineage_assignments.copy()
        seq_data = seq_data.copy()
        metadata = metadata.copy()

        if node_col is None:
            if "node" in issues.columns:
                node_col = "node"
            elif "Node" in issues.columns:
                node_col = "Node"
            else:
                raise ValueError("issues must contain 'Node' or 'node' column")

        issues["number"] = pd.NA

        def _parent_in_range(x) -> bool:
            if pd.isna(x) or x == "":
                return False
            try:
                v = int(float(x))
                return 1 <= v <= parent_max
            except Exception:
                return False

        parent_mask = issues[parent_col].map(_parent_in_range)
        m = int(parent_mask.sum())

        for i in range(min(m, len(issues))):
            try:
                p = int(float(issues.at[i, parent_col]))
            except Exception:
                continue
            parent_rows = issues.index[issues[cluster_col].astype("Int64") == p].tolist()
            if not parent_rows:
                continue
            parent_n_tips = issues.at[parent_rows[0], n_tips_col]
            child_n_tips = issues.at[i, n_tips_col]
            if pd.isna(parent_n_tips) or pd.isna(child_n_tips):
                issues.at[i, "number"] = pd.NA
            else:
                issues.at[i, "number"] = int(parent_n_tips) - int(child_n_tips)

        num = pd.to_numeric(issues["number"], errors="coerce")
        bad_mask = num.notna() & (num < float(min_parent_tip_diff))
        if bool(bad_mask.any()):
            bad_nodes = issues.loc[bad_mask, node_col].astype(int).tolist()
            nodes_diff = nodes_diff.loc[
                ~nodes_diff["Node"].astype(int).isin(bad_nodes)
            ].copy()
            nodes_diff.reset_index(drop=True, inplace=True)

        lineage_assignments = lineage_assignments.copy()
        lineage_assignments[la_cluster_col] = pd.NA

        for _, row in nodes_diff.iterrows():
            ape_node = int(row["Node"])
            cluster_val = row[cluster_col]
            if tip_labels_col in nodes_diff.columns and pd.notna(row.get(tip_labels_col, pd.NA)):
                tips_str = str(row.get(tip_labels_col, "")).strip()
                tips = [t.strip() for t in tips_str.split(",") if t.strip()] if tips_str else []
            else:
                tips = self._tips_for_ape_node(ape_node)
            if tips:
                lineage_assignments.loc[
                    lineage_assignments[la_tip_col].isin(tips), la_cluster_col
                ] = cluster_val

        nodes_diff["numbers"] = range(1, len(nodes_diff) + 1)

        for _, row in nodes_diff.iterrows():
            old = row[cluster_col]
            new = int(row["numbers"])
            lineage_assignments.loc[
                lineage_assignments[la_cluster_col] == old, la_cluster_col
            ] = new

        nodes_diff[cluster_col] = nodes_diff["numbers"].astype(int)

        la_map = lineage_assignments.set_index(la_tip_col)[la_cluster_col]
        seq_data["cluster"] = seq_data[seq_id_col].map(la_map)

        sequence_data = seq_data.copy()
        node_data = nodes_diff.copy()
        if "overlaps" in node_data.columns:
            node_data = node_data.sort_values(
                "overlaps", ascending=False, kind="mergesort"
            ).reset_index(drop=True)

        sequence_data[seq_id_col] = sequence_data[seq_id_col].astype(str).str.strip()
        seq_data[seq_id_col] = seq_data[seq_id_col].astype(str).str.strip()

        if seq_id_col not in metadata.columns:
            meta_cols_lc = {c.lower(): c for c in metadata.columns}
            if seq_id_col.lower() in meta_cols_lc:
                meta_id_col = meta_cols_lc[seq_id_col.lower()]
            else:
                raise ValueError(f"metadata missing '{seq_id_col}' column")
        else:
            meta_id_col = seq_id_col

        metadata[meta_id_col] = metadata[meta_id_col].astype(str).str.strip()

        assign_col = None
        meta_cols_lc = {c.lower(): c for c in metadata.columns}
        if metadata_assignment_col.lower() in meta_cols_lc:
            assign_col = meta_cols_lc[metadata_assignment_col.lower()]
        else:
            for cand in ("assignment", "Assignment", "clade", "Clade", "lineage", "Lineage"):
                if cand.lower() in meta_cols_lc:
                    assign_col = meta_cols_lc[cand.lower()]
                    break

        sequence_data["previous"] = pd.NA
        seq_data["previous"] = pd.NA
        if assign_col is not None:
            prev_map = metadata.set_index(meta_id_col)[assign_col]
            sequence_data["previous"] = sequence_data[seq_id_col].map(prev_map)
            seq_data["previous"] = seq_data[seq_id_col].map(prev_map)

        previous_assignments = pd.DataFrame(
            {"assignment": pd.unique(sequence_data["previous"]), "node": pd.NA}
        )

        return (
            nodes_diff, lineage_assignments, seq_data,
            sequence_data, node_data, previous_assignments,
        )

    # ------------------------------------------------------------------ assign previous

    def assign_previous_to_nodes_and_rename_clusters(
        self,
        node_data: pd.DataFrame,
        sequence_data: pd.DataFrame,
        previous_assignments: pd.DataFrame,
        *,
        node_col: str = "Node",
        id_col: str = "ID",
        seq_prev_col: str = "previous",
        node_prev_col: str = "previous",
        cluster_col: str = "cluster",
        overlaps_col: str = "overlaps",
        assignment_col: str = "assignment",
        node_index_col: str = "node",
        suffix: str = "_A1",
        root_label: str = "A1",
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        node_data = node_data.copy()
        sequence_data = sequence_data.copy()
        previous_assignments = previous_assignments.copy()

        sequence_data[id_col] = sequence_data[id_col].astype(str).str.strip()
        if node_prev_col not in node_data.columns:
            node_data[node_prev_col] = pd.NA

        tip_to_prev = sequence_data.set_index(id_col)[seq_prev_col]

        prev_list: List[object] = []
        for ape_node in node_data[node_col].astype(int).tolist():
            tips = self._descendant_tips_for_ape_node(ape_node)
            series = tip_to_prev.reindex(tips).astype("string").fillna("NA")
            uniq = pd.unique(series)
            node_prev = ", ".join([str(x) for x in uniq]) if len(uniq) else pd.NA
            prev_list.append(node_prev)
        node_data[node_prev_col] = prev_list

        previous_assignments[node_index_col] = pd.NA
        prev_series = node_data[node_prev_col].astype("string")

        for i in range(len(previous_assignments)):
            a = previous_assignments.at[i, assignment_col]
            if pd.isna(a):
                previous_assignments.at[i, node_index_col] = pd.NA
                continue
            a_str = str(a)
            hits = node_data.index[prev_series == a_str].tolist()
            previous_assignments.at[i, node_index_col] = hits[0] if hits else pd.NA

        base = previous_assignments[assignment_col].astype("string")
        possible_names = pd.DataFrame(
            {"names": pd.Series(np.tile(base.to_numpy(dtype=object), 26), dtype="string")}
        )

        previous_assignments[assignment_col] = (
            previous_assignments[assignment_col].astype("string").fillna("NA") + suffix
        )

        if cluster_col not in node_data.columns:
            node_data[cluster_col] = pd.NA

        for i in range(len(previous_assignments)):
            nidx = previous_assignments.at[i, node_index_col]
            if pd.isna(nidx):
                continue
            nidx = int(nidx)
            node_data.at[nidx, cluster_col] = previous_assignments.at[i, assignment_col]

        any_root_assigned = (
            previous_assignments[node_index_col].dropna().astype(int) == 0
        ).any()
        if not any_root_assigned and len(node_data) > 0:
            node_data.at[0, cluster_col] = root_label

        if overlaps_col in node_data.columns:
            node_data = node_data.sort_values(
                overlaps_col, ascending=False, kind="mergesort"
            ).reset_index(drop=True)

        return node_data, previous_assignments, possible_names

    # ------------------------------------------------------------------ problem letters

    @staticmethod
    def _problem_letters_up_to_bz1() -> List[str]:
        cols: List[str] = []
        for prefix in ["", "A", "B"]:
            for c in string.ascii_uppercase:
                col = f"{prefix}{c}" if prefix else c
                cols.append(f"{col}1")
                if col == "BZ":
                    return cols
        return cols

    # ------------------------------------------------------------------ apply issue cluster labels

    def apply_issue_cluster_labels_and_fix_commas(
        self,
        node_data: pd.DataFrame,
        possible_names: pd.DataFrame,
        *,
        node_col: str = "Node",
        overlaps_col: str = "overlaps",
        cluster_col: str = "cluster",
        previous_col: str = "previous",
        possible_names_col: str = "names",
    ) -> Tuple[pd.DataFrame, pd.Series]:
        nd = node_data.copy()

        if overlaps_col in nd.columns:
            nd = nd.sort_values(overlaps_col, ascending=False, kind="mergesort").reset_index(drop=True)

        nd["test"] = pd.NA
        problem_letters = self._problem_letters_up_to_bz1()

        pn = possible_names.copy()
        pn[possible_names_col] = pn[possible_names_col].astype("string")
        pn = pn.sort_values(possible_names_col, kind="mergesort").reset_index(drop=True)

        L = len(problem_letters)
        base = pn[possible_names_col].astype("string").fillna("NA").reset_index(drop=True)
        if len(base) == 0:
            recycled = pd.Series(["NA"] * L, dtype="string")
        else:
            recycled = pd.Series([base.iloc[i % len(base)] for i in range(L)], dtype="string")
        possible_names_vec = recycled + "_" + pd.Series(problem_letters, dtype="string")

        if cluster_col not in nd.columns:
            nd[cluster_col] = pd.NA
        nd[cluster_col] = nd[cluster_col].astype("string")

        root_node = int(nd.at[0, node_col])
        # Use include_self=False: root node's own descendants (not itself)
        root_desc = set(self._internal_descendants_ape(root_node, include_self=False))

        issues = [i for i, n in enumerate(nd[node_col].astype(int).tolist()) if n not in root_desc]

        x = 0
        y = 1
        numbers = [0]

        while len(issues) > y:
            issues = issues[1:]
            if not issues:
                break
            idx = issues[0]
            prev_val = nd.at[idx, previous_col] if previous_col in nd.columns else pd.NA
            prev_str = "NA" if pd.isna(prev_val) else str(prev_val)
            nd.at[idx, cluster_col] = f"{prev_str}_{problem_letters[x]}"
            numbers.append(idx)

            nodes: Set[int] = set(
                self._internal_descendants_ape(int(nd.at[0, node_col]), include_self=False)
            )
            for i in range(1, len(numbers)):
                if i >= len(nd):
                    break
                nodes.update(
                    self._internal_descendants_ape(int(nd.at[i, node_col]), include_self=False)
                )

            issues = [i for i, n in enumerate(nd[node_col].astype(int).tolist()) if n not in nodes]
            y += 1

            has_b1 = nd[cluster_col].astype("string").str.contains(problem_letters[1], na=False).any()
            if not has_b1:
                x = 0
            else:
                x = min(x + 1, len(problem_letters) - 1)

        # fix comma clusters
        while True:
            comma_mask = nd[cluster_col].astype("string").str.contains(",", na=False)
            if not comma_mask.any():
                break
            used = set(
                v for v in nd[cluster_col].dropna().astype(str).tolist()
                if v in problem_letters
            )
            next_letter = next((L for L in problem_letters if L not in used), None)
            if next_letter is None:
                break
            bad_values = pd.unique(nd.loc[comma_mask, cluster_col].astype("string"))
            nd.loc[nd[cluster_col].astype("string") == bad_values[0], cluster_col] = next_letter

        return nd, possible_names_vec

    # ------------------------------------------------------------------ relabel clusters

    def relabel_clusters_with_descendants_and_deduplicate(
        self,
        node_data: pd.DataFrame,
        possible_names: Iterable,
        *,
        node_col: str = "Node",
        cluster_col: str = "cluster",
        test_col: str = "test",
        problem_letters: Optional[List[str]] = None,
    ) -> Tuple[pd.DataFrame, List[str], List[str]]:
        nd = node_data.copy()

        if "overlaps" in nd.columns:
            nd["_orig_row"] = range(len(nd))
            nd = nd.sort_values(
                ["overlaps", "_orig_row"], ascending=[False, True], kind="mergesort"
            ).reset_index(drop=True)
            nd = nd.drop(columns=["_orig_row"])

        if cluster_col not in nd.columns:
            nd[cluster_col] = pd.NA
        nd[cluster_col] = nd[cluster_col].astype("string")

        if test_col not in nd.columns:
            nd[test_col] = pd.NA
        nd[test_col] = nd[test_col].astype("string")

        if problem_letters is None:
            problem_letters = self._problem_letters_up_to_bz1()

        if isinstance(possible_names, pd.Series):
            possible_list = possible_names.astype("string").tolist()
        else:
            possible_list = [str(x) for x in possible_names]

        # R ladder: str_replace replaces the FIRST occurrence (not anchored)
        ladder = [
            ("A1", "B1"), ("B1", "C1"), ("C1", "D1"), ("D1", "E1"),
            ("E1", "F1"), ("F1", "G1"), ("G1", "H1"), ("H1", "I1"),
            ("I1", "J1"), ("J1", "K1"), ("K1", "L1"), ("L1", "M1"),
            ("M1", "N1"), ("N1", "O1"), ("O1", "P1"), ("P1", "Q1"),
            ("Q1", "R1"), ("R1", "S1"), ("S1", "T1"),
        ]

        node_vec = nd[node_col].astype(int).tolist()

        for i, ape_node in enumerate(node_vec):
            # include_self=False matches R descendants(..., ignore.tip=TRUE)
            desc_nodes = set(self._internal_descendants_ape(int(ape_node), include_self=False))
            idx = [j for j, n in enumerate(node_vec) if int(n) in desc_nodes]

            base = nd.at[i, cluster_col]
            base = "NA" if pd.isna(base) else str(base)
            nd.loc[idx, test_col] = f"{base}.1"

            # Apply ladder to ENTIRE column, replace first match only (str_replace semantics)
            for src, dst in ladder:
                # Pattern matches src followed by .<1char>.<1char>.<1char> anywhere in string
                pat = rf"{re.escape(src)}\.[^.]\.[^.]\.[^.]"
                nd[test_col] = nd[test_col].str.replace(pat, dst, regex=True, n=1)

            majors = nd[test_col].str.contains("_", na=False)
            nd.loc[majors, cluster_col] = nd.loc[majors, test_col]

            for name in possible_list:
                hits = nd.index[nd[cluster_col] == name].tolist()
                if len(hits) > 1:
                    y = 1
                    for p in hits[1:]:
                        s = nd.at[p, cluster_col]
                        if pd.isna(s):
                            continue
                        s = str(s)
                        if "_" not in s:
                            continue
                        base_part, letter_part = s.split("_", 1)
                        try:
                            li = problem_letters.index(letter_part)
                        except ValueError:
                            continue
                        new_i = min(li + y, len(problem_letters) - 1)
                        nd.at[p, cluster_col] = f"{base_part}_{problem_letters[new_i]}"
                        y += 1

            dup_vals = pd.unique(nd.loc[nd[cluster_col].duplicated(), cluster_col].astype("string"))
            dup_vals = [d for d in dup_vals if pd.notna(d)]
            duplicates_with_dot = [d for d in dup_vals if str(d).count(".") != 0]

            for dup in duplicates_with_dot:
                hits = nd.index[nd[cluster_col] == dup].tolist()
                if len(hits) <= 1:
                    continue
                x = 1
                for row_idx in hits[1:]:
                    parts = str(nd.at[row_idx, cluster_col]).split(".")
                    try:
                        parts[-1] = str(int(parts[-1]) + x)
                    except Exception:
                        parts[-1] = f"{parts[-1]}{x}"
                    x += 1
                    nd.at[row_idx, cluster_col] = ".".join(parts)

        dup_vals = pd.unique(nd.loc[nd[cluster_col].duplicated(), cluster_col].astype("string"))
        dup_vals = [d for d in dup_vals if pd.notna(d)]
        problems_no_dot = [d for d in dup_vals if str(d).count(".") == 0]
        duplicates_with_dot = [d for d in dup_vals if str(d).count(".") != 0]

        return nd, duplicates_with_dot, problems_no_dot

    # ------------------------------------------------------------------ finalize lineages

    def finalize_lineages_rstyle(
        self,
        node_data: pd.DataFrame,
        *,
        node_col: str = "Node",
        cluster_col: str = "cluster",
        test_col: str = "test",
        diff_col: str = "diff_count",
        n_tips_col: str = "n_tips",
        include_self_in_desc: bool = False,
    ) -> pd.DataFrame:
        """
        Final lineage-label cleanup pass mirroring R node_info_nolength.R.

        Key fix vs original: ladder patterns are NOT anchored (^...$) so they
        match R's str_replace behaviour which replaces the first occurrence
        anywhere in the string.
        """
        nd = node_data.copy()

        if cluster_col not in nd.columns:
            nd[cluster_col] = pd.NA
        nd[cluster_col] = nd[cluster_col].astype("string")
        nd[test_col] = pd.Series([pd.NA] * len(nd), dtype="string")

        problem_letters: List[str] = self._problem_letters_up_to_bz1()

        unclassified = nd.index[~nd[cluster_col].str.contains("_", na=False)].tolist()
        if unclassified:
            unclassified = unclassified[1:]

        # Ladder: match FIRST occurrence anywhere (no ^ $ anchors)
        ladder = [
            ("A1", "B1"), ("B1", "C1"), ("C1", "D1"), ("D1", "E1"),
            ("E1", "F1"), ("F1", "G1"), ("G1", "H1"), ("H1", "I1"),
            ("I1", "J1"), ("J1", "K1"), ("K1", "L1"), ("L1", "M1"),
            ("M1", "N1"), ("N1", "O1"), ("O1", "P1"), ("P1", "Q1"),
            ("Q1", "R1"), ("R1", "S1"), ("S1", "T1"),
        ]

        node_vec = nd[node_col].astype(int).tolist()

        for i in range(len(node_vec)):
            ape_node = int(node_vec[i])
            desc_nodes = set(
                self._internal_descendants_ape(ape_node, include_self=include_self_in_desc)
            )
            test_idx = nd.index[nd[node_col].astype(int).isin(desc_nodes)].tolist()

            base = nd.at[i, cluster_col]
            base = "NA" if pd.isna(base) else str(base)
            if test_idx:
                nd.loc[test_idx, test_col] = f"{base}.1"

            # Apply ladder to ENTIRE column with first-match-only replacement (no anchors)
            for src, dst in ladder:
                pat = rf"{re.escape(src)}\.[^.]\.[^.]\.[^.]"
                nd[test_col] = nd[test_col].str.replace(pat, dst, regex=True, n=1)

            if unclassified:
                nd.loc[unclassified, cluster_col] = nd.loc[unclassified, test_col]

            for v, letter in enumerate(problem_letters):
                hits = nd.index[nd[cluster_col] == letter].tolist()
                if len(hits) > 1:
                    y = 1
                    for row_idx in hits[1:]:
                        new_i = min(v + y, len(problem_letters) - 1)
                        nd.at[row_idx, cluster_col] = problem_letters[new_i]
                        y += 1

            dup_vals = pd.unique(
                nd.loc[nd[cluster_col].duplicated(), cluster_col].astype("string")
            )
            dup_vals = [d for d in dup_vals if pd.notna(d)]
            duplicates_with_dot = [d for d in dup_vals if str(d).count(".") != 0]

            for dup in duplicates_with_dot:
                rows = nd.index[nd[cluster_col] == dup].tolist()
                if len(rows) <= 1:
                    continue
                x = 1
                for r in rows[1:]:
                    parts = str(nd.at[r, cluster_col]).split(".")
                    try:
                        parts[-1] = str(int(parts[-1]) + x)
                    except Exception:
                        parts[-1] = f"{parts[-1]}{x}"
                    x += 1
                    nd.at[r, cluster_col] = ".".join(parts)

            while True:
                num = pd.to_numeric(nd[cluster_col], errors="coerce")
                mask = num.notna() & (num >= 1) & (num <= 1000)
                if not mask.any():
                    break
                used = set(nd[cluster_col].dropna().astype(str)).intersection(problem_letters)
                letter = next(L for L in problem_letters if L not in used)
                nd.loc[mask, cluster_col] = letter

            while True:
                mask = nd[cluster_col].isna() | nd[cluster_col].astype("string").str.contains(
                    "NA", na=False
                )
                if not mask.any():
                    break
                used = set(nd[cluster_col].dropna().astype(str)).intersection(problem_letters)
                letter = next(L for L in problem_letters if L not in used)
                nd[cluster_col] = nd[cluster_col].astype("string").str.replace(
                    "NA", letter, regex=False
                )
                nd.loc[nd[cluster_col].isna(), cluster_col] = letter

            x = 1
            duplicates = pd.unique(
                nd.loc[nd[cluster_col].duplicated(), cluster_col].astype("string")
            )
            duplicates = [d for d in duplicates if pd.notna(d)]
            while duplicates:
                for dup in duplicates:
                    rows = nd.index[nd[cluster_col] == dup].tolist()
                    if len(rows) <= 1:
                        continue
                    for r in rows[1:]:
                        base_str = str(nd.at[r, cluster_col]).split("_", 1)[0]
                        if x >= len(problem_letters):
                            x = len(problem_letters) - 1
                        nd.at[r, cluster_col] = f"{base_str}_{problem_letters[x]}"
                        x += 1
                duplicates = pd.unique(
                    nd.loc[nd[cluster_col].duplicated(), cluster_col].astype("string")
                )
                duplicates = [d for d in duplicates if pd.notna(d)]

        # ---------------------------------------------------------------- final output formatting
        # Drop test/previous columns
        drop_cols = [c for c in nd.columns if "test" in c or "previous" in c]
        if drop_cols:
            nd = nd.drop(columns=sorted(set(drop_cols)), errors="ignore")

        if "bootstrap" in nd.columns:
            nd = nd.drop(columns=["bootstrap"], errors="ignore")

        rename_map = {
            node_col: "node",
            n_tips_col: "n_tips",
            diff_col: "n_diff_ancestor",
            cluster_col: "lineage",
        }
        keep_cols = [node_col, n_tips_col, diff_col, cluster_col]
        nd = nd.loc[:, [c for c in keep_cols if c in nd.columns]].copy()
        nd = nd.rename(columns=rename_map)

        # Prefix clade name onto lineages that don't already have it
        lineage = nd["lineage"].astype("string")
        dash_idx = lineage[lineage.str.contains("-", na=False)].index.tolist()
        under_idx = lineage[lineage.str.contains("_", na=False)].index.tolist()

        if dash_idx:
            first = str(lineage.loc[dash_idx[0]])
            clade = first.split("-", 1)[0]
            mask = ~lineage.str.contains("-", na=False)
            nd.loc[mask, "lineage"] = clade + " " + nd.loc[mask, "lineage"].astype("string")
        elif under_idx:
            first = str(lineage.loc[under_idx[0]])
            clade = first.split(" ", 1)[0]
            mask = ~lineage.str.contains("_", na=False)
            nd.loc[mask, "lineage"] = clade + " " + nd.loc[mask, "lineage"].astype("string")

        # Remove rows with NA in lineage
        mask_bad = nd["lineage"].astype("string").str.contains("NA", na=False)
        if bool(mask_bad.any()):
            nd = nd.loc[~mask_bad].copy()

        nd = nd.reset_index(drop=True)
        return nd


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--contree", required=True)
    ap.add_argument("--aligned_fasta", required=True)
    ap.add_argument("--metadata", required=True)
    ap.add_argument("--ancestral", required=True)
    ap.add_argument("--bootstrap", type=float, default=95.0)
    ap.add_argument("--min_tips", type=int, default=10)
    ap.add_argument("--min_cluster_size", type=int, default=2)
    ap.add_argument("--base_dir", default="tmp", help="Base output directory. Default: tmp")
    return ap.parse_args()


def main() -> None:
    args = parse_args()

    mapper = ContreeNodeMapper(
        args.contree,
        digits=7,
        order="preorder",
        support_mode="ufboot",
    )

    # --- Build node list ---
    node_data = mapper.build_node_data(threshold=args.bootstrap)
    _, nodes_5 = mapper.add_tip_counts_and_filter(node_data, min_tips=args.min_tips)

    # --- Sequences / metadata ---
    seq_data = mapper.build_seq_data_from_fasta(args.aligned_fasta)
    metadata = mapper.load_metadata(args.metadata)
    seq_data = mapper.add_year_to_seq_data(seq_data, metadata)

    ancestral_dict = mapper.fasta_to_dict(args.ancestral)

    # --- Descendant tips per node ---
    nodes_5 = mapper.add_clade_tip_labels(nodes_5)

    # --- diff_count ---
    compare_nodes, node_to_alltips, node_to_ancestral_tips = mapper.compare_nodes(
        nodes_5, ancestral_dict
    )

    nodes_diff = compare_nodes.loc[compare_nodes["diff_count"] != 0].copy()
    nodes_diff = nodes_diff.sort_values("Node", kind="mergesort").reset_index(drop=True)

    # --- overlaps ---
    nodes_diff["overlaps"] = mapper.compute_overlaps_rstyle(nodes_diff, node_col="Node")

    # --- clustering ---
    keep = set(nodes_diff["NODE_key"].tolist())
    node_to_tips_diff = {k: v for k, v in node_to_alltips.items() if k in keep}

    tree = mapper.load_tree()
    all_tips = [t.name for t in tree.get_terminals() if getattr(t, "name", None)]

    nodes_diff_final, lineage_assignments, summary = mapper.assign_lineages_from_overlapping_nodes(
        nodes_diff=nodes_diff,
        node_to_tips=node_to_tips_diff,
        all_tips=all_tips,
        min_cluster_size=args.min_cluster_size,
        node_key_col="NODE_key",
    )

    # --- issues table ---
    issues = mapper.build_issues_table_rstyle(
        nodes_diff_final,
        node_col="Node",
        n_tips_col="n_tips",
        cluster_col="cluster",
    )

    # --- prune & reassign ---
    (
        nodes_diff_final,
        lineage_assignments,
        seq_data,
        sequence_data,
        node_data,
        previous_assignments,
    ) = mapper.prune_by_parent_tip_difference_and_reassign(
        issues=issues,
        nodes_diff=nodes_diff_final,
        lineage_assignments=lineage_assignments,
        seq_data=seq_data,
        metadata=metadata,
        parent_max=1000,
        min_parent_tip_diff=5,
    )

    # --- assign previous ---
    node_data, previous_assignments, possible_names = (
        mapper.assign_previous_to_nodes_and_rename_clusters(
            node_data=node_data,
            sequence_data=sequence_data,
            previous_assignments=previous_assignments,
        )
    )

    # --- issue cluster labels ---
    node_data, possible_names_vec = mapper.apply_issue_cluster_labels_and_fix_commas(
        node_data=node_data,
        possible_names=possible_names,
    )

    # --- relabel with descendants ---
    node_data, duplicates_with_dot, problems_no_dot = (
        mapper.relabel_clusters_with_descendants_and_deduplicate(
            node_data=node_data,
            possible_names=possible_names_vec,
        )
    )

    # --- finalize lineages ---
    node_data = mapper.finalize_lineages_rstyle(
        node_data,
        node_col="Node",
        cluster_col="cluster",
        diff_col="diff_count",
    )

    # Add a 1-based row number as the final, unnamed column.
    node_data = node_data.copy()
    node_data[""] = range(1, len(node_data) + 1)

    base_dir = Path(args.base_dir)
    base_dir.mkdir(parents=True, exist_ok=True)
    output_path = base_dir / "final_node_data.tsv"
    node_data.to_csv(output_path, sep="\t", index=False)
    print(node_data.to_string(index=False))
    print(f"Wrote final node data to: {output_path}")


if __name__ == "__main__":
    main()